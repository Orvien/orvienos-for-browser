// OrvienOS for Browser - script-v1.0.0.js

// メイン初期化処理
document.addEventListener('DOMContentLoaded', () => {
    loadBackground();
    initializeSearch();
    initializeDateTime();
    initializeSettings();
    initializeWeather(); 
    initializeLinks();
    initializeTodos();
    initializeMemo();
});

// 背景機能
function loadBackground() {
    chrome.storage.local.get(['backgroundImageUrl'], (result) => {
        if (result.backgroundImageUrl) {
            document.body.style.backgroundImage = `url('${result.backgroundImageUrl}')`;
        } else {
            // 保存された背景画像がなければicon.pngを設定
            const iconUrl = chrome.runtime.getURL('icon-v1.0.0.png');
            document.body.style.backgroundImage = `url('${iconUrl}')`;
        }
    });
}
function initializeSettings() {
    const settingsButton = document.getElementById('settings-button');
    const settingsPanel = document.getElementById('settings-panel');
    const closeButton = document.getElementById('close-settings-button');
    
    const urlInput = document.getElementById('bg-url-input');
    const urlSaveButton = document.getElementById('bg-url-save-button');
    const fileInput = document.getElementById('bg-file-input');
    const resetButton = document.getElementById('bg-reset-button');

    // 設定ボタンでパネルの表示/非表示を切り替え
    settingsButton.addEventListener('click', () => {
        settingsPanel.classList.toggle('visible');
    });

    // 閉じるボタンでパネルを非表示
    closeButton.addEventListener('click', () => {
        settingsPanel.classList.remove('visible');
    });

    // URL保存ボタンの処理
    urlSaveButton.addEventListener('click', () => {
        const imageUrl = urlInput.value.trim();
        if (imageUrl) {
            setBackground(imageUrl);
        }
    });

    // リセットボタンの処理
    resetButton.addEventListener('click', () => {
        resetBackground();
    });

    // ファイル選択時の処理
    fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (!file) return;

        // ファイルサイズチェック (5MB上限)
        if (file.size > 5 * 1024 * 1024) {
            alert('ファイルサイズが大きすぎます。5MB以下の画像を選択してください。');
            fileInput.value = ''; // 選択をリセット
            return;
        }

        const reader = new FileReader();

        // ファイル読み込みが完了したときの処理
        reader.onload = (e) => {
            const dataUrl = e.target.result;
            setBackground(dataUrl);
        };

        // ファイルをData URLとして読み込む
        reader.readAsDataURL(file);
    });
}
// 背景を設定・保存するヘルパー関数
function setBackground(imageUrl) {
    document.body.style.backgroundImage = `url('${imageUrl}')`;
    chrome.storage.local.set({ backgroundImageUrl: imageUrl }, () => {
        console.log('Background image saved.');
        document.getElementById('settings-panel').classList.remove('visible'); // 保存後にパネルを閉じる
    });
}
// 背景をリセット・保存するヘルパー関数
function resetBackground() {
    document.body.style.backgroundImage = 'none';
    chrome.storage.local.remove('backgroundImageUrl', () => {
        console.log('Background image reset.');
        document.getElementById('settings-panel').classList.remove('visible');
    });
}


// 検索機能
function initializeSearch() {
    const searchForm = document.getElementById('search-form');
    const searchInput = document.getElementById('search-input');
    searchForm.addEventListener('submit', (event) => {
        event.preventDefault(); 
        const query = searchInput.value;
        if (query) {
            const searchUrl = 'https://www.google.com/search?q=' + encodeURIComponent(query);
            window.location.href = searchUrl;
        }
    });
}

// 日時機能
function initializeDateTime() {
    const clockElement = document.getElementById('clock-widget');
    const dateElement = document.getElementById('date-widget');
    function update() {
        const now = new Date();
        clockElement.textContent = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        dateElement.textContent = `${now.getFullYear()} / ${String(now.getMonth() + 1).padStart(2, '0')} / ${String(now.getDate()).padStart(2, '0')}`;
    }
    update();
    setInterval(update, 1000);
}

// 天気機能 (Orvien Weather Tool)
async function initializeWeather() {
    const apiKey = "a0c10e788f45172468eaa8fe20eedf11"; // お客様のAPIキー
    const weatherWidget = document.getElementById('weather-widget');
    let { weatherCity } = await chrome.storage.local.get('weatherCity');
    if (!weatherCity) {
        weatherCity = 'Tokyo';
        await chrome.storage.local.set({ weatherCity });
    }
    fetchWeather(apiKey, weatherCity);
    weatherWidget.addEventListener('click', async () => {
        const currentCity = weatherWidget.querySelector('.weather-city')?.textContent || weatherCity;
        const newCity = prompt('天気を表示する都市名を入力してください (例: London):', currentCity);
        if (newCity && newCity.trim() !== '' && newCity !== currentCity) {
            await chrome.storage.local.set({ weatherCity: newCity.trim() });
            fetchWeather(apiKey, newCity.trim());
        }
    });
}
async function fetchWeather(apiKey, city) {
    const weatherWidget = document.getElementById('weather-widget');
    weatherWidget.innerHTML = `<p>Loading weather...</p>`;
    if (apiKey === "" || apiKey === "YOUR_API_KEY_HERE") {
        return weatherWidget.innerHTML = `<h3>Orvien Weather Tool</h3><p style="font-size: 0.9rem;">Please set API Key.</p>`;
    }
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=ja`;
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`City not found or API error.`);
        const data = await response.json();
        renderWeather(data);
    } catch (error) {
        console.error("Weather fetch error:", error);
        weatherWidget.innerHTML = `<h3>Orvien Weather Tool</h3><p>Could not load weather for "${city}".</p>`;
    }
}
function renderWeather(data) {
    const weatherWidget = document.getElementById('weather-widget');
    const temp = Math.round(data.main.temp);
    const iconCode = data.weather[0].icon;
    weatherWidget.innerHTML = `
        <h3>Orvien Weather Tool</h3>
        <div class="weather-main">
            <img src="https://openweathermap.org/img/wn/${iconCode}@2x.png" alt="${data.weather[0].description}" class="weather-icon">
            <span class="weather-temp">${temp}°C</span>
        </div>
        <div class="weather-city">${data.name}</div>
    `;
}

// リンク機能 (Orvien Links Tool)
let links = [];
const defaultLinks = [{ name: 'Orvien', url: 'https://orvien.github.io' }, { name: 'Extensions', url: 'https://chrome://extensions' }];
async function initializeLinks() {
    const addButton = document.getElementById('add-link-button');
    const linksList = document.getElementById('links-list');
    const result = await chrome.storage.local.get('links');
    links = result.links || defaultLinks;
    renderAllLinks();
    addButton.addEventListener('click', addNewLink);
    linksList.addEventListener('click', (event) => {
        const target = event.target;
        const li = target.closest('li');
        if (!li) return;

        // クリックされたのが<a>タグの場合の処理を追加
        if (target.tagName === 'A') {
            event.preventDefault(); // デフォルトのリンク遷移を停止！
            const href = target.getAttribute('href');
            if (href) {
                // chrome.tabs.create で開く
                chrome.tabs.create({ url: href, active: true }, function(tab) {
                    // エラーハンドリング: 無効なURLスキームの場合
                    if (chrome.runtime.lastError) {
                        console.error("Failed to open URL:", href, chrome.runtime.lastError.message);
                        alert(`URLを開けませんでした: ${href}\n\n原因: ${chrome.runtime.lastError.message || '不明なエラー'}\n\nURLスキームが正しく認識されているかご確認ください。`);
                    }
                });
            }
            return; // リンククリック時は他の処理を行わない
        }

        const index = parseInt(li.dataset.index, 10);
        if (target.classList.contains('delete-link-button')) deleteLink(index, li);
        else if (target.classList.contains('edit-link-button')) renderEditForm(li, index);
        else if (target.classList.contains('save-edit-button')) updateLink(index, li.querySelector('.edit-name-input').value, li.querySelector('.edit-url-input').value, li);
        else if (target.classList.contains('cancel-edit-button')) cancelEdit(li, index);
    });
}
function createLinkListItemHTML(link, index) { return `<a href="${link.url}" title="${link.name} - ${link.url}">${link.name}</a><span class="edit-link-button" data-index="${index}">✏️</span><span class="delete-link-button" data-index="${index}">×</span>`; }
function renderAllLinks() {
    const linksList = document.getElementById('links-list');
    linksList.innerHTML = '';
    const fragment = document.createDocumentFragment();
    links.forEach((link, index) => {
        const li = document.createElement('li');
        li.dataset.index = index;
        li.innerHTML = createLinkListItemHTML(link, index);
        fragment.appendChild(li);
    });
    linksList.appendChild(fragment);
}
function saveLinks() { chrome.storage.local.set({ links: links }); }
function addNewLink() {
    const name = prompt('リンクの名前を入力してください:');
    if (!name) return;
    const url = prompt('リンクのURLを入力してください:', ''); 
    if (!url || url.trim() === '') {
        alert('URLを入力してください。');
        return;
    }
    links.push({ name, url: url.trim() });
    saveLinks();
    const li = document.createElement('li');
    const newIndex = links.length - 1;
    li.dataset.index = newIndex;
    li.innerHTML = createLinkListItemHTML(links[newIndex], newIndex);
    document.getElementById('links-list').appendChild(li);
}
function deleteLink(index, liElement) {
    if (confirm(`「${links[index].name}」を削除しますか？`)) {
        links.splice(index, 1);
        saveLinks();
        liElement.remove();
        document.querySelectorAll('#links-list li').forEach((li, newIndex) => {
            li.dataset.index = newIndex;
            const editBtn = li.querySelector('.edit-link-button');
            const deleteBtn = li.querySelector('.delete-link-button');
            if(editBtn) editBtn.dataset.index = newIndex;
            if(deleteBtn) deleteBtn.dataset.index = newIndex;
        });
    }
}
function renderEditForm(li, index) {
    const link = links[index];
    li.classList.add('editing');
    li.innerHTML = `<div class="edit-form-container"><input type="text" class="edit-name-input" value="${link.name}" autocomplete="off"><input type="text" class="edit-url-input" value="${link.url}" autocomplete="off"><div class="edit-form-buttons"><button class="save-edit-button">Save</button><button class="cancel-edit-button">Cancel</button></div></div>`;
}
function updateLink(index, newName, newUrl, liElement) {
    if (!newName || newName.trim() === '') {
        alert('名前を入力してください。');
        return;
    }
    if (!newUrl || newUrl.trim() === '') {
        alert('URLを入力してください。');
        return;
    }
    links[index] = { name: newName.trim(), url: newUrl.trim() };
    saveLinks();
    liElement.classList.remove('editing');
    liElement.innerHTML = createLinkListItemHTML(links[index], index);
}
function cancelEdit(liElement, index) {
    liElement.classList.remove('editing');
    liElement.innerHTML = createLinkListItemHTML(links[index], index);
}

// ToDoリスト機能 (Orvien Todo Tool)
let todos = [];
const defaultTodos = [{ id: Date.now() + 1, text: "OrvienOSのToDoリストを試す", completed: true }, { id: Date.now() + 2, text: "新しいタスクを追加してみる", completed: false }];
async function initializeTodos() {
    const todoListElement = document.getElementById('todo-list');
    const newTodoInput = document.getElementById('new-todo-input');
    const result = await chrome.storage.local.get('todos');
    todos = result.todos || defaultTodos;
    renderAllTodos();
    newTodoInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && newTodoInput.value.trim() !== '') {
            addTodo(newTodoInput.value.trim());
            newTodoInput.value = '';
        }
    });
    todoListElement.addEventListener('click', (event) => {
        const li = event.target.closest('li');
        if (!li) return;
        const todoId = parseInt(li.dataset.id, 10);
        if (event.target.matches('.todo-checkbox')) toggleTodoCompleted(todoId);
        if (event.target.matches('.todo-delete-btn')) deleteTodo(todoId);
    });
}
function renderAllTodos() {
    const todoListElement = document.getElementById('todo-list');
    todoListElement.innerHTML = '';
    const fragment = document.createDocumentFragment();
    todos.forEach(todo => fragment.appendChild(createTodoElement(todo)));
    todoListElement.appendChild(fragment);
}
function createTodoElement(todo) {
    const li = document.createElement('li');
    li.dataset.id = todo.id;
    li.innerHTML = `<input type="checkbox" class="todo-checkbox" ${todo.completed ? 'checked' : ''}>
                    <span class="todo-text ${todo.completed ? 'completed' : ''}">${todo.text}</span>
                    <button class="todo-delete-btn">×</button>`;
    return li;
}
function saveTodos() { chrome.storage.local.set({ todos: todos }); }
function addTodo(text) {
    const newTodo = { id: Date.now(), text: text, completed: false };
    todos.push(newTodo);
    saveTodos();
    document.getElementById('todo-list').appendChild(createTodoElement(newTodo));
}
function toggleTodoCompleted(id) {
    const todo = todos.find(t => t.id === id);
    if (todo) {
        todo.completed = !todo.completed;
        saveTodos();
        const textSpan = document.querySelector(`#todo-list li[data-id='${id}'] .todo-text`);
        if(textSpan) textSpan.classList.toggle('completed', todo.completed);
    }
}
function deleteTodo(id) {
    todos = todos.filter(t => t.id !== id);
    saveTodos();
    const li = document.querySelector(`#todo-list li[data-id='${id}']`);
    if(li) li.remove();
}

// メモ帳機能 (Orvien Memo Tool)
let memoTimeout;
async function initializeMemo() {
    const memoTextarea = document.getElementById('memo-textarea');
    const result = await chrome.storage.local.get('memoContent');
    if (result.memoContent) memoTextarea.value = result.memoContent;
    memoTextarea.addEventListener('input', () => {
        clearTimeout(memoTimeout);
        memoTimeout = setTimeout(() => saveMemo(memoTextarea.value), 500);
    });
}
function saveMemo(content) {
    chrome.storage.local.set({ memoContent: content }).then(() => console.log('Memo saved.'));
}
